# KÝ DUYỆT TÀI LIỆU

## Chạy website

1. Cài Python 3.10 trở lên.
2. Mở Terminal tại thư mục dự án.
3. Cài thư viện:

```bash
pip install -r requirements.txt
```

4. Khởi động:

```bash
streamlit run app.py
```

Website sẽ chạy trên trình duyệt.

## Chức năng MVP

- Upload PDF
- Thiết lập luồng phê duyệt theo thứ tự
- Ký duyệt hoặc từ chối
- Theo dõi trạng thái
- Tải tài liệu đã hoàn thành với watermark `TÀI LIỆU ĐÃ ĐƯỢC DUYỆT`

## Bước phát triển tiếp theo

Phiên bản hiện tại lưu dữ liệu trong phiên chạy để dễ thử nghiệm. Bước tiếp theo nên kết nối Supabase để có:
- Đăng nhập và phân quyền
- Lưu trữ tài liệu trên Cloud
- Cơ sở dữ liệu lâu dài
- Thông báo email
- Nhật ký ký duyệt
- Chữ ký điện tử nâng cao
