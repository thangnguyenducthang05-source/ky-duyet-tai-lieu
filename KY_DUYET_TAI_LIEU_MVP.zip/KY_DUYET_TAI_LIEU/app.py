import streamlit as st
import fitz  # PyMuPDF
from pathlib import Path
from datetime import datetime
import uuid

st.set_page_config(page_title="KÝ DUYỆT TÀI LIỆU", page_icon="📄", layout="wide")

DATA = Path("data")
UPLOADS = DATA / "uploads"
SIGNED = DATA / "approved"
UPLOADS.mkdir(parents=True, exist_ok=True)
SIGNED.mkdir(parents=True, exist_ok=True)

if "documents" not in st.session_state:
    st.session_state.documents = []

def status_badge(status):
    colors = {
        "Chờ ký": "🟡",
        "Đang xử lý": "🔵",
        "Đã hoàn thành": "🟢",
        "Bị từ chối": "🔴",
    }
    return f"{colors.get(status, '⚪')} {status}"

def add_watermark(input_path, output_path):
    doc = fitz.open(input_path)
    for page in doc:
        rect = page.rect
        shape = page.new_shape()
        shape.insert_text(
            fitz.Point(rect.width * 0.18, rect.height * 0.55),
            "TÀI LIỆU ĐÃ ĐƯỢC DUYỆT",
            fontsize=22,
            rotate=0,
            color=(0.55, 0.55, 0.55),
            fill_opacity=0.25,
        )
        shape.commit()
    doc.save(output_path)
    doc.close()

with st.sidebar:
    st.title("📄 KÝ DUYỆT")
    st.caption("Hệ thống quản lý và ký duyệt tài liệu")
    page = st.radio("Điều hướng", ["🏠 Tổng quan", "📤 Gửi tài liệu", "✍️ Ký duyệt", "📁 Kho tài liệu"])
    st.divider()
    st.caption("Phiên bản MVP • Streamlit + PyMuPDF")

st.title(page)

if page == "🏠 Tổng quan":
    docs = st.session_state.documents
    waiting = sum(d["status"] == "Chờ ký" for d in docs)
    completed = sum(d["status"] == "Đã hoàn thành" for d in docs)
    rejected = sum(d["status"] == "Bị từ chối" for d in docs)
    sent = len(docs)

    a, b, c, d = st.columns(4)
    a.metric("🟡 Chờ ký", waiting)
    b.metric("📤 Tổng tài liệu", sent)
    c.metric("🟢 Đã hoàn thành", completed)
    d.metric("🔴 Bị từ chối", rejected)

    st.subheader("Tài liệu gần đây")
    if not docs:
        st.info("Chưa có tài liệu nào. Hãy vào mục **Gửi tài liệu** để tải lên PDF.")
    else:
        for doc in reversed(docs[-8:]):
            with st.container(border=True):
                col1, col2, col3 = st.columns([4, 2, 2])
                col1.write(f"**📄 {doc['name']}**")
                col1.caption(f"Tạo lúc: {doc['created']}")
                col2.write(status_badge(doc["status"]))
                col3.write("Người duyệt: " + doc["current_signer"])

elif page == "📤 Gửi tài liệu":
    st.subheader("Gửi tài liệu vào quy trình ký duyệt")
    with st.form("upload_form", clear_on_submit=True):
        title = st.text_input("Tên tài liệu")
        file = st.file_uploader("Tải lên file PDF", type=["pdf"])
        st.markdown("**Thiết lập luồng phê duyệt theo thứ tự**")
        signer1 = st.text_input("Bước 1 – Người duyệt", placeholder="Ví dụ: Trưởng phòng")
        signer2 = st.text_input("Bước 2 – Người ký", placeholder="Ví dụ: Giám đốc")
        submitted = st.form_submit_button("📤 Gửi tài liệu")

    if submitted:
        if not title or not file or not signer1:
            st.error("Vui lòng nhập tên tài liệu, chọn PDF và ít nhất một người duyệt.")
        else:
            doc_id = str(uuid.uuid4())[:8]
            filename = f"{doc_id}_{file.name}"
            path = UPLOADS / filename
            path.write_bytes(file.getbuffer())
            flow = [x for x in [signer1, signer2] if x.strip()]
            st.session_state.documents.append({
                "id": doc_id,
                "name": title,
                "path": str(path),
                "status": "Chờ ký",
                "flow": flow,
                "step": 0,
                "current_signer": flow[0],
                "created": datetime.now().strftime("%d/%m/%Y %H:%M"),
                "note": "",
            })
            st.success("Đã gửi tài liệu vào quy trình phê duyệt!")

elif page == "✍️ Ký duyệt":
    docs = [d for d in st.session_state.documents if d["status"] in ["Chờ ký", "Đang xử lý"]]
    if not docs:
        st.info("Hiện không có tài liệu nào cần ký.")
    else:
        options = {f"{d['name']} — {status_badge(d['status'])}": d for d in docs}
        selected_label = st.selectbox("Chọn tài liệu", list(options.keys()))
        doc = options[selected_label]

        st.write(f"**Người đang đến lượt:** {doc['current_signer']}")
        st.write("**Quy trình:** " + " → ".join(doc["flow"]))

        col1, col2 = st.columns(2)
        with col1:
            approve = st.button("✅ Ký duyệt", type="primary")
        with col2:
            reject = st.button("❌ Từ chối")

        note = st.text_area("Ghi chú (nếu có)")

        if approve:
            doc["note"] = note
            doc["step"] += 1
            if doc["step"] >= len(doc["flow"]):
                doc["status"] = "Đã hoàn thành"
                doc["current_signer"] = "Hoàn tất"
                st.success("Tài liệu đã hoàn thành quy trình ký duyệt!")
            else:
                doc["status"] = "Đang xử lý"
                doc["current_signer"] = doc["flow"][doc["step"]]
                st.success(f"Đã ký duyệt. Tài liệu được chuyển đến: {doc['current_signer']}")
            st.rerun()

        if reject:
            doc["status"] = "Bị từ chối"
            doc["note"] = note
            doc["current_signer"] = "Dừng quy trình"
            st.warning("Tài liệu đã bị từ chối.")
            st.rerun()

elif page == "📁 Kho tài liệu":
    docs = st.session_state.documents
    if not docs:
        st.info("Kho tài liệu đang trống.")
    else:
        for doc in reversed(docs):
            with st.expander(f"📄 {doc['name']} — {status_badge(doc['status'])}"):
                st.write(f"**Luồng duyệt:** {' → '.join(doc['flow'])}")
                st.write(f"**Ghi chú:** {doc['note'] or 'Không có'}")

                original = Path(doc["path"])
                if original.exists():
                    st.download_button(
                        "⬇️ Tải bản gốc",
                        data=original.read_bytes(),
                        file_name=original.name,
                        mime="application/pdf",
                        key=f"original_{doc['id']}",
                    )

                if doc["status"] == "Đã hoàn thành" and original.exists():
                    approved_name = f"DA_DUYET_{original.name}"
                    approved_path = SIGNED / approved_name
                    if not approved_path.exists():
                        add_watermark(str(original), str(approved_path))
                    st.success("Bản tải xuống đã được đóng chữ chìm: TÀI LIỆU ĐÃ ĐƯỢC DUYỆT")
                    st.download_button(
                        "⬇️ Tải tài liệu đã được duyệt",
                        data=approved_path.read_bytes(),
                        file_name=approved_name,
                        mime="application/pdf",
                        key=f"approved_{doc['id']}",
                    )
